package healify_home.heal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealApplication.class, args);
	}

}
