package healify_home.heal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealApplicationTests {

	@Test
	void contextLoads() {
	}

}
